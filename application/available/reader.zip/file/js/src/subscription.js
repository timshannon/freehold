// jshint esnext:true

export var test = "imported subscription";

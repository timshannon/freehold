function installApp() {
    console.log("app install post script test successful");
}
